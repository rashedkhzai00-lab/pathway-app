(() => {
  const card = document.getElementById('card');
  const trail = document.getElementById('pathTrail');
  const trunk = document.getElementById('trunk');
  const skipBtn = document.getElementById('skipBtn');
  const redirectMsg = document.getElementById('redirectMsg');

  const steps = {}; // step name -> element
  document.querySelectorAll('.step').forEach(el => {
    steps[el.dataset.step] = el;
  });

  let currentStep = 'welcome';
  const answers = {};

  // branch path definitions per intent, drawn from the trunk top
  const branchPaths = {
    learn: "M160,420 C160,360 110,330 90,260",
    focus: "M160,420 C160,360 160,330 160,250",
    plan:  "M160,420 C160,360 190,330 200,260",
    build: "M160,420 C160,360 225,330 240,270"
  };

  function showStep(name){
    Object.values(steps).forEach(el => el.hidden = true);
    steps[name].hidden = false;
    steps[name].style.animation = 'none';
    // force reflow to restart animation
    void steps[name].offsetWidth;
    steps[name].style.animation = '';
    currentStep = name;
  }

  function lightTrunk(){
    trunk.classList.add('lit');
  }

  function drawBranch(intent){
    const existing = document.getElementById('branch-' + intent);
    if (existing) { existing.classList.add('drawn'); return; }
    const ns = "http://www.w3.org/2000/svg";
    const path = document.createElementNS(ns, 'path');
    path.setAttribute('id', 'branch-' + intent);
    path.setAttribute('class', 'branch-line');
    path.setAttribute('d', branchPaths[intent]);
    trail.appendChild(path);
    // force reflow then add drawn class to trigger transition
    void path.getBoundingClientRect();
    requestAnimationFrame(() => path.classList.add('drawn'));
  }

  function routeTo(route, value){
    answers.route = route;
    answers.value = value;
    localStorage.setItem('pathway:lastAnswers', JSON.stringify(answers));

    const destinations = {
      'driving-theory': { url: 'modules/study.html', label: 'your driving theory practice' },
      'study-generic':  { url: 'modules/study.html?mode=generic', label: 'study mode' },
      'focus':           { url: `modules/focus.html?len=${value}`, label: 'a focus session' },
      'calendar':        { url: `modules/plan.html?view=${value}`, label: 'your plan' },
      'creator':         { url: `modules/create.html?mode=${value}`, label: 'the question creator' }
    };

    const dest = destinations[route] || { url: 'modules/all.html', label: 'the app' };

    showStep('redirecting');
    redirectMsg.textContent = `Taking you to ${dest.label}…`;

    setTimeout(() => {
      window.location.href = dest.url;
    }, 650);
  }

  // welcome -> q1
  card.querySelector('[data-next="q1"]').addEventListener('click', () => {
    lightTrunk();
    showStep('q1');
  });

  // q1 choice buttons (intent selection)
  steps['q1'].querySelectorAll('.choice').forEach(btn => {
    btn.addEventListener('click', () => {
      const intent = btn.dataset.value;
      answers.intent = intent;
      drawBranch(intent);

      const detailStepMap = {
        learn: 'learn-detail',
        focus: 'focus-detail',
        plan: 'plan-detail',
        build: 'build-detail'
      };
      showStep(detailStepMap[intent]);
    });
  });

  // all detail-step choice buttons that carry data-route
  document.querySelectorAll('.choice[data-route]').forEach(btn => {
    btn.addEventListener('click', () => {
      routeTo(btn.dataset.route, btn.dataset.value);
    });
  });

  skipBtn.addEventListener('click', () => {
    localStorage.setItem('pathway:lastAnswers', JSON.stringify({ route: 'all' }));
    window.location.href = 'modules/all.html';
  });

  // If user has a recent routing preference, we still always show onboarding —
  // app intentionally asks each time since "what you need" changes session to session.
})();
