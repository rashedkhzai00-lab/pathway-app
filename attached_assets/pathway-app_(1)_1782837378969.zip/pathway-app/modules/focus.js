(() => {
  const ringProgress = document.getElementById('ringProgress');
  const timeDisplay = document.getElementById('timeDisplay');
  const cycleLabel = document.getElementById('cycleLabel');
  const modeLabel = document.getElementById('modeLabel');
  const startPauseBtn = document.getElementById('startPauseBtn');
  const resetBtn = document.getElementById('resetBtn');
  const skipBtn = document.getElementById('skipBtn');
  const focusCard = document.querySelector('.focus-card');
  const lengthPicker = document.getElementById('lengthPicker');
  const lenOpts = document.querySelectorAll('.len-opt');
  const streakText = document.getElementById('streakText');

  const CIRCUMFERENCE = 2 * Math.PI * 108; // matches r=108 in svg

  // break length mapping (minutes) based on focus length chosen
  const breakMap = { 15: 5, 25: 5, 50: 10 };

  // read length from query string, default 25
  const params = new URLSearchParams(window.location.search);
  let focusMinutes = parseInt(params.get('len'), 10);
  if (![15, 25, 50].includes(focusMinutes)) focusMinutes = 25;

  let phase = 'work'; // 'work' | 'break'
  let round = 1;
  let totalSeconds = focusMinutes * 60;
  let remainingSeconds = totalSeconds;
  let running = false;
  let intervalId = null;
  let endTimestamp = null; // for drift-free countdown

  const STREAK_KEY = 'pathway:focusStreak';

  function todayKey(){
    const d = new Date();
    return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;
  }

  function getStreakCount(){
    try{
      const raw = JSON.parse(localStorage.getItem(STREAK_KEY) || '{}');
      return raw[todayKey()] || 0;
    }catch(e){ return 0; }
  }

  function incrementStreak(){
    let raw = {};
    try{ raw = JSON.parse(localStorage.getItem(STREAK_KEY) || '{}'); }catch(e){}
    const key = todayKey();
    raw[key] = (raw[key] || 0) + 1;
    localStorage.setItem(STREAK_KEY, JSON.stringify(raw));
    renderStreak();
  }

  function renderStreak(){
    const count = getStreakCount();
    streakText.textContent = count === 1
      ? '1 session completed today'
      : `${count} sessions completed today`;
  }

  function setLengthActive(min){
    lenOpts.forEach(btn => {
      btn.classList.toggle('active', parseInt(btn.dataset.min,10) === min);
    });
  }

  function applyLength(min){
    focusMinutes = min;
    setLengthActive(min);
    if (phase === 'work' && !running){
      totalSeconds = focusMinutes * 60;
      remainingSeconds = totalSeconds;
      renderTime();
      renderRing();
    }
  }

  function formatTime(sec){
    const m = Math.floor(sec / 60).toString().padStart(2,'0');
    const s = Math.floor(sec % 60).toString().padStart(2,'0');
    return `${m}:${s}`;
  }

  function renderTime(){
    timeDisplay.textContent = formatTime(Math.max(0, remainingSeconds));
    document.title = running
      ? `${formatTime(remainingSeconds)} · ${phase === 'work' ? 'Focusing' : 'Break'} — Pathway`
      : 'Focus — Pathway';
  }

  function renderRing(){
    const fraction = remainingSeconds / totalSeconds;
    const offset = CIRCUMFERENCE * (1 - fraction);
    ringProgress.style.strokeDashoffset = offset;
  }

  function renderPhaseUI(){
    if (phase === 'work'){
      focusCard.classList.remove('break-mode');
      modeLabel.textContent = 'Focus session';
      cycleLabel.textContent = `Round ${round}`;
      lengthPicker.classList.remove('is-disabled');
    } else {
      focusCard.classList.add('break-mode');
      modeLabel.textContent = 'Break — step away';
      cycleLabel.textContent = `After round ${round}`;
      lengthPicker.classList.add('is-disabled');
    }
  }

  function startPhase(newPhase){
    phase = newPhase;
    totalSeconds = (phase === 'work' ? focusMinutes : breakMap[focusMinutes]) * 60;
    remainingSeconds = totalSeconds;
    renderPhaseUI();
    renderTime();
    renderRing();
  }

  function tick(){
    const now = Date.now();
    remainingSeconds = Math.round((endTimestamp - now) / 1000);
    if (remainingSeconds <= 0){
      remainingSeconds = 0;
      renderTime();
      renderRing();
      completePhase();
      return;
    }
    renderTime();
    renderRing();
  }

  function completePhase(){
    pause();
    playChime();
    if (phase === 'work'){
      incrementStreak();
      startPhase('break');
    } else {
      round += 1;
      startPhase('work');
    }
    // brief auto-pause so user consciously starts next phase (avoids surprise transitions)
  }

  function start(){
    if (running) return;
    running = true;
    endTimestamp = Date.now() + remainingSeconds * 1000;
    intervalId = setInterval(tick, 250);
    startPauseBtn.textContent = 'Pause';
    startPauseBtn.classList.add('is-running');
    renderTime();
  }

  function pause(){
    running = false;
    clearInterval(intervalId);
    startPauseBtn.textContent = 'Start';
    startPauseBtn.classList.remove('is-running');
    renderTime();
  }

  function reset(){
    pause();
    remainingSeconds = totalSeconds;
    renderTime();
    renderRing();
  }

  function skip(){
    pause();
    if (phase === 'work'){
      startPhase('break');
    } else {
      round += 1;
      startPhase('work');
    }
  }

  function playChime(){
    try{
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const now = ctx.currentTime;
      [660, 880].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.0001, now + i * 0.18);
        gain.gain.exponentialRampToValueAtTime(0.15, now + i * 0.18 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.18 + 0.5);
        osc.connect(gain).connect(ctx.destination);
        osc.start(now + i * 0.18);
        osc.stop(now + i * 0.18 + 0.55);
      });
    }catch(e){ /* audio not available, fail silently */ }
  }

  startPauseBtn.addEventListener('click', () => {
    running ? pause() : start();
  });

  resetBtn.addEventListener('click', reset);
  skipBtn.addEventListener('click', skip);

  lenOpts.forEach(btn => {
    btn.addEventListener('click', () => applyLength(parseInt(btn.dataset.min,10)));
  });

  // init
  setLengthActive(focusMinutes);
  renderPhaseUI();
  renderTime();
  renderRing();
  renderStreak();
})();
