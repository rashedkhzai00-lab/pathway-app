(() => {
  const BANK_KEY = 'pathway:questionBank';
  const WEAK_KEY = 'pathway:weakSpots';
  const SESSION_KEY = 'pathway:activeSession';

  // ---- views ----
  const homeView = document.getElementById('homeView');
  const categoryView = document.getElementById('categoryView');
  const sessionView = document.getElementById('sessionView');
  const resultsView = document.getElementById('resultsView');
  const views = [homeView, categoryView, sessionView, resultsView];

  function showView(view){
    views.forEach(v => v.hidden = (v !== view));
  }

  // ---- home elements ----
  const statTotal = document.getElementById('statTotal');
  const statWeak = document.getElementById('statWeak');
  const statCats = document.getElementById('statCats');
  const resumeBanner = document.getElementById('resumeBanner');
  const resumeText = document.getElementById('resumeText');
  const resumeBtn = document.getElementById('resumeBtn');
  const drillWeakBtn = document.getElementById('drillWeakBtn');
  const weakSub = document.getElementById('weakSub');
  const quickPracticeBtn = document.getElementById('quickPracticeBtn');
  const categoryBtn = document.getElementById('categoryBtn');
  const examBtn = document.getElementById('examBtn');
  const emptyBank = document.getElementById('emptyBank');
  const actionList = document.querySelector('.action-list');
  const statsRow = document.getElementById('statsRow');

  // ---- category view ----
  const catBackBtn = document.getElementById('catBackBtn');
  const categoryList = document.getElementById('categoryList');

  // ---- session view ----
  const sessionExitBtn = document.getElementById('sessionExitBtn');
  const sessionTimer = document.getElementById('sessionTimer');
  const progressFill = document.getElementById('progressFill');
  const progressLabel = document.getElementById('progressLabel');
  const qCategoryTag = document.getElementById('qCategoryTag');
  const qText = document.getElementById('qText');
  const answerOptions = document.getElementById('answerOptions');
  const explanationBox = document.getElementById('explanationBox');
  const explanationText = document.getElementById('explanationText');
  const nextBtn = document.getElementById('nextBtn');

  // ---- results view ----
  const resultsHeadline = document.getElementById('resultsHeadline');
  const resultsScore = document.getElementById('resultsScore');
  const resultsPct = document.getElementById('resultsPct');
  const resultsDetail = document.getElementById('resultsDetail');
  const backHomeBtn = document.getElementById('backHomeBtn');
  const drillMissedBtn = document.getElementById('drillMissedBtn');

  let timerInterval = null;
  let lastMissedIds = [];

  // ---------- storage helpers ----------
  function loadBank(){
    try{ return JSON.parse(localStorage.getItem(BANK_KEY) || '[]'); }
    catch(e){ return []; }
  }

  function loadWeak(){
    try{ return JSON.parse(localStorage.getItem(WEAK_KEY) || '{}'); }
    catch(e){ return {}; }
  }

  function saveWeak(w){ localStorage.setItem(WEAK_KEY, JSON.stringify(w)); }

  function loadSession(){
    try{ return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); }
    catch(e){ return null; }
  }

  function saveSession(s){ localStorage.setItem(SESSION_KEY, JSON.stringify(s)); }
  function clearSession(){ localStorage.removeItem(SESSION_KEY); }

  function shuffle(arr){
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--){
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  // ---------- home rendering ----------
  function renderHome(){
    const bank = loadBank();
    const weak = loadWeak();
    const weakIds = Object.keys(weak).filter(id => weak[id] > 0);
    const cats = new Set(bank.map(q => q.category));

    statTotal.textContent = bank.length;
    statWeak.textContent = weakIds.length;
    statCats.textContent = cats.size;

    weakSub.textContent = weakIds.length
      ? `${weakIds.length} question${weakIds.length === 1 ? '' : 's'} you've missed before`
      : 'No weak spots yet — nice';
    drillWeakBtn.disabled = weakIds.length === 0;
    drillWeakBtn.style.opacity = weakIds.length === 0 ? '0.5' : '1';
    drillWeakBtn.style.cursor = weakIds.length === 0 ? 'default' : 'pointer';

    const hasBank = bank.length > 0;
    actionList.hidden = !hasBank;
    statsRow.hidden = !hasBank;
    emptyBank.hidden = hasBank;

    const session = loadSession();
    if (session && session.currentIndex < session.questionIds.length){
      resumeBanner.hidden = false;
      const remaining = session.questionIds.length - session.currentIndex;
      resumeText.textContent = `${remaining} question${remaining === 1 ? '' : 's'} left in your last session.`;
    } else {
      resumeBanner.hidden = true;
    }
  }

  // ---------- starting sessions ----------
  function startSession(questionIds, mode, opts = {}){
    const session = {
      mode,
      questionIds,
      currentIndex: 0,
      correctCount: 0,
      missedIds: [],
      answers: {},
      startTime: Date.now(),
      timeLimitSeconds: opts.timeLimitSeconds || null,
      categoryName: opts.categoryName || null
    };
    saveSession(session);
    renderQuestion();
    showView(sessionView);
  }

  quickPracticeBtn.addEventListener('click', () => {
    const bank = loadBank();
    const ids = shuffle(bank.map(q => q.id)).slice(0, 12);
    startSession(ids, 'quick');
  });

  examBtn.addEventListener('click', () => {
    const bank = loadBank();
    const ids = shuffle(bank.map(q => q.id)).slice(0, Math.min(20, bank.length));
    startSession(ids, 'exam', { timeLimitSeconds: 20 * 60 });
  });

  drillWeakBtn.addEventListener('click', () => {
    if (drillWeakBtn.disabled) return;
    const weak = loadWeak();
    const ids = Object.keys(weak).filter(id => weak[id] > 0);
    startSession(shuffle(ids), 'weak');
  });

  categoryBtn.addEventListener('click', () => {
    renderCategoryList();
    showView(categoryView);
  });

  catBackBtn.addEventListener('click', () => {
    renderHome();
    showView(homeView);
  });

  function renderCategoryList(){
    const bank = loadBank();
    const counts = {};
    bank.forEach(q => { counts[q.category] = (counts[q.category] || 0) + 1; });
    const cats = Object.keys(counts).sort();

    categoryList.innerHTML = '';
    cats.forEach(cat => {
      const item = document.createElement('button');
      item.className = 'category-item';
      item.innerHTML = `<span>${escapeHtml(cat)}</span><span class="category-count">${counts[cat]}</span>`;
      item.addEventListener('click', () => {
        const ids = shuffle(bank.filter(q => q.category === cat).map(q => q.id)).slice(0, 15);
        startSession(ids, 'category', { categoryName: cat });
      });
      categoryList.appendChild(item);
    });
  }

  // ---------- session question rendering ----------
  function renderQuestion(){
    const session = loadSession();
    if (!session) return;

    const bank = loadBank();
    const bankMap = Object.fromEntries(bank.map(q => [q.id, q]));
    const total = session.questionIds.length;
    const idx = session.currentIndex;

    if (idx >= total){
      finishSession();
      return;
    }

    const qId = session.questionIds[idx];
    const q = bankMap[qId];

    // skip if question was deleted from bank since session started
    if (!q){
      session.currentIndex += 1;
      saveSession(session);
      renderQuestion();
      return;
    }

    progressFill.style.width = `${Math.round((idx / total) * 100)}%`;
    progressLabel.textContent = `Question ${idx + 1} of ${total}`;
    qCategoryTag.textContent = q.category;
    qText.textContent = q.text;

    explanationBox.hidden = true;
    nextBtn.hidden = true;

    answerOptions.innerHTML = '';
    const letters = ['A','B','C','D'];
    q.options.forEach((opt, i) => {
      const btn = document.createElement('button');
      btn.className = 'answer-opt';
      btn.innerHTML = `<span class="opt-letter">${letters[i]}</span><span>${escapeHtml(opt)}</span>`;
      btn.addEventListener('click', () => handleAnswer(i, q));
      answerOptions.appendChild(btn);
    });

    // timer
    clearInterval(timerInterval);
    if (session.timeLimitSeconds){
      sessionTimer.hidden = false;
      updateTimerDisplay(session);
      timerInterval = setInterval(() => {
        const s = loadSession();
        if (!s) { clearInterval(timerInterval); return; }
        const elapsed = Math.floor((Date.now() - s.startTime) / 1000);
        const remaining = s.timeLimitSeconds - elapsed;
        if (remaining <= 0){
          clearInterval(timerInterval);
          finishSession();
          return;
        }
        sessionTimer.textContent = formatClock(remaining);
      }, 1000);
    } else {
      sessionTimer.hidden = true;
    }
  }

  function updateTimerDisplay(session){
    const elapsed = Math.floor((Date.now() - session.startTime) / 1000);
    const remaining = Math.max(0, session.timeLimitSeconds - elapsed);
    sessionTimer.textContent = formatClock(remaining);
  }

  function formatClock(sec){
    const m = Math.floor(sec / 60).toString().padStart(2,'0');
    const s = Math.floor(sec % 60).toString().padStart(2,'0');
    return `${m}:${s}`;
  }

  function handleAnswer(chosenIdx, q){
    const session = loadSession();
    if (!session) return;

    const buttons = answerOptions.querySelectorAll('.answer-opt');
    buttons.forEach(b => b.disabled = true);

    const isCorrect = chosenIdx === q.correctIndex;
    buttons[q.correctIndex].classList.add('correct');
    if (!isCorrect) buttons[chosenIdx].classList.add('incorrect');

    // update weak spots
    const weak = loadWeak();
    if (isCorrect){
      if (weak[q.id]) {
        weak[q.id] = Math.max(0, weak[q.id] - 1);
        if (weak[q.id] === 0) delete weak[q.id];
      }
      session.correctCount += 1;
    } else {
      weak[q.id] = (weak[q.id] || 0) + 1;
      session.missedIds.push(q.id);
    }
    saveWeak(weak);

    session.answers[q.id] = chosenIdx;
    saveSession(session);

    if (q.explanation){
      explanationText.textContent = q.explanation;
      explanationBox.hidden = false;
    }
    nextBtn.hidden = false;
    nextBtn.focus();
  }

  nextBtn.addEventListener('click', () => {
    const session = loadSession();
    if (!session) return;
    session.currentIndex += 1;
    saveSession(session);
    renderQuestion();
  });

  sessionExitBtn.addEventListener('click', () => {
    clearInterval(timerInterval);
    renderHome();
    showView(homeView);
  });

  function finishSession(){
    clearInterval(timerInterval);
    const session = loadSession();
    if (!session) return;

    const total = session.questionIds.length;
    const correct = session.correctCount;
    const pct = total ? Math.round((correct / total) * 100) : 0;

    lastMissedIds = session.missedIds.slice();

    resultsScore.textContent = `${correct}/${total}`;
    resultsPct.textContent = `${pct}%`;
    resultsHeadline.textContent = pct >= 80 ? 'Strong session.' : pct >= 50 ? 'Good progress.' : 'Practice makes this easier.';
    resultsDetail.textContent = lastMissedIds.length
      ? `${lastMissedIds.length} question${lastMissedIds.length === 1 ? '' : 's'} got added to your weak spots.`
      : 'Nothing missed this round.';

    drillMissedBtn.hidden = lastMissedIds.length === 0;

    clearSession();
    showView(resultsView);
  }

  backHomeBtn.addEventListener('click', () => {
    renderHome();
    showView(homeView);
  });

  drillMissedBtn.addEventListener('click', () => {
    if (lastMissedIds.length === 0) return;
    startSession(shuffle(lastMissedIds), 'weak');
  });

  resumeBtn.addEventListener('click', () => {
    renderQuestion();
    showView(sessionView);
  });

  function escapeHtml(str){
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }

  // ---------- init ----------
  renderHome();
  showView(homeView);
})();
